﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using System.Data;
using System.Data.SqlClient;



namespace DataAccessLayer
{
    public class DataAccessDAL
    {
        //verifying admin
        public bool AdminLogin(EntityAccessEAL entity,String password)
        {
            SqlConnection sqlConnection = null;
            SqlCommand sqlCommand = null;
            SqlDataReader sqlDataReader = null;
            try
            {
                string username = entity.UserName;
               // string password = entity.Password;
                sqlConnection = DbConnection.OpenConnection();
                string query = "select Password from  Login where UserName=@username";
                sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.Parameters.Add("@username", SqlDbType.VarChar);
                sqlCommand.Parameters["@username"].Value = entity.UserName;
                sqlDataReader = sqlCommand.ExecuteReader();
                while(sqlDataReader.Read())
                {

                    if (sqlDataReader.GetSqlString(0).ToString().Equals(entity.Password))
                        return true;
                }
                
            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                DbConnection.CloseConnection(sqlConnection);
            }
           return false;
        }
        //fetching customer id
        public int FetchCustomerID(EntityAccessEAL entity)
        {

            SqlConnection sqlConnection = null;
            SqlCommand sqlCommand = null;
            SqlDataReader sqlDataReader = null;
            try
            {
                string custname = entity.CustName;
                // string password = entity.Password;
                sqlConnection = DbConnection.OpenConnection();
                string query = "select CustID from CustomerDetails  where CustName=@custname";
                sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.Parameters.Add("@custname", SqlDbType.VarChar);
                sqlCommand.Parameters["@custname"].Value = entity.CustName;
                sqlDataReader = sqlCommand.ExecuteReader();
                while (sqlDataReader.Read())
                {

                    int value = sqlDataReader.GetInt32(0);
                        return value;
                }

            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                DbConnection.CloseConnection(sqlConnection);
            }
            return -1;
        }


        //fetching supplier id

        public int FetchSupplierID(EntityAccessEAL entity)
        {

            SqlConnection sqlConnection = null;
            SqlCommand sqlCommand = null;
            SqlDataReader sqlDataReader = null;
            try
            {
                string phoneno = entity.SupplierPhoneNo;
                // string password = entity.Password;
                sqlConnection = DbConnection.OpenConnection();
                string query = "select SupplierID from SupplierDetails  where PhoneNo=@phoneno";
                sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.Parameters.Add("@phoneno", SqlDbType.VarChar);
                sqlCommand.Parameters["@phoneno"].Value = entity.SupplierPhoneNo;
                sqlDataReader = sqlCommand.ExecuteReader();
                while (sqlDataReader.Read())
                {

                    int value = sqlDataReader.GetInt32(0);
                    return value;
                }

            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                DbConnection.CloseConnection(sqlConnection);
            }
            return -1;
        }
        //inserting customer details
        public bool InsertCustomerData(EntityAccessEAL entity)
        {
            
            SqlConnection sqlConnection = null;
            SqlCommand sqlCommand = null;
           
            try
            {
                string CustName = entity.CustName;
                string CustAddress = entity.CustAddress;
                string CustPhoneNo = entity.CustPhoneNo;
                sqlConnection = DbConnection.OpenConnection();
                string query = "insert into CustomerDetails values(@CustName,@CustAddress,@CustPhoneNo)";
                sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.Parameters.Add("@CustName", SqlDbType.VarChar);
                sqlCommand.Parameters["@CustName"].Value = entity.CustName;
                sqlCommand.Parameters.Add("@CustAddress", SqlDbType.VarChar);
                sqlCommand.Parameters["@CustAddress"].Value = entity.CustAddress;
                sqlCommand.Parameters.Add("@CustPhoneNo", SqlDbType.BigInt);
                sqlCommand.Parameters["@CustPhoneNo"].Value = entity.CustPhoneNo;



               int res= sqlCommand.ExecuteNonQuery();
              if(res>0)
                        return true;
              

            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                DbConnection.CloseConnection(sqlConnection);
            }
            return false;
        }


        //inserting the product order by customer

        public void InsertProdouctData(EntityAccessEAL entityAccessEAL,int custid)
        {

            SqlConnection sqlConnection = null;
            SqlCommand sqlCommand = null;

            try
            {
                string ProductQuantity = entityAccessEAL.ProductQuantity;
                string ProductName = entityAccessEAL.ProductName;
                int ProductTotalAmount = entityAccessEAL.ProductTotalAmount;
               
               
                sqlConnection = DbConnection.OpenConnection();
                string query = "insert into CustomerOrdersDetails (OrderQty ,OrderName,TotalPrice,CustID)values(@ProductQuantity,@ProductName,@ProductTotalAmount,@Custid)";


                sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.Parameters.Add("@ProductQuantity", SqlDbType.VarChar);
                sqlCommand.Parameters["@ProductQuantity"].Value = entityAccessEAL.ProductQuantity;


                sqlCommand.Parameters.Add("@ProductName", SqlDbType.VarChar);
                sqlCommand.Parameters["@ProductName"].Value = ProductName;

                sqlCommand.Parameters.Add("@ProductTotalAmount", SqlDbType.Int);
                sqlCommand.Parameters["@ProductTotalAmount"].Value = ProductTotalAmount;

                sqlCommand.Parameters.Add("@custid", SqlDbType.Int);
                sqlCommand.Parameters["@custid"].Value = custid;



                sqlCommand.ExecuteNonQuery();
               


            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                DbConnection.CloseConnection(sqlConnection);
            }
        

        }


        public void InsertSupplierOrderData(EntityAccessEAL entityAccessEAL1, int supplierid)
        {
            SqlConnection sqlConnection = null;
            SqlCommand sqlCommand = null;

            try
            {
                string departmentname = entityAccessEAL1.SupplierDepartmentName;
                string productname = entityAccessEAL1.SupplierDepartmentName;
                string productquantity = entityAccessEAL1.SupplierProductQuantity;
                //string ProductQuantity = entityAccessEAL.ProductQuantity;
                //string ProductName = entityAccessEAL.ProductName;
                //int ProductTotalAmount = entityAccessEAL.ProductTotalAmount;


                sqlConnection = DbConnection.OpenConnection();
                string query = "insert into SupplierPurchaseDetails (DeptName ,ProductName,Product" +
                    "quantity,SupplierID)values(@departmentname,@productname,@productquantity,@supplierid)";


                sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.Parameters.Add("@departmentname", SqlDbType.VarChar);
                sqlCommand.Parameters["@departmentname"].Value = departmentname;


                sqlCommand.Parameters.Add("@productname", SqlDbType.VarChar);
                sqlCommand.Parameters["@productname"].Value = productname;

                sqlCommand.Parameters.Add("@productquantity", SqlDbType.Int);
                sqlCommand.Parameters["@productquantity"].Value = productquantity;

                sqlCommand.Parameters.Add("@SupplierID", SqlDbType.Int);
                sqlCommand.Parameters["@supplierid"].Value = supplierid;



                sqlCommand.ExecuteNonQuery();



            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                DbConnection.CloseConnection(sqlConnection);
            }

        }
        //inserting supplier data

        public bool InsertSupplierData(EntityAccessEAL entity)
        {
            SqlConnection sqlConnection = null;
            SqlCommand sqlCommand = null;

            try
            {
                string SupplierName = entity.SupplierName;
                string SupplierAddress = entity.SupplierAddress;
                string SupplierPhoneNo = entity.SupplierPhoneNo;
                sqlConnection = DbConnection.OpenConnection();
                string query = "insert into SupplierDetails values(@SupplierName,@SupplierAddress,@SupplierPhoneNo)";
                sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.Parameters.Add("@SupplierName", SqlDbType.VarChar);
                sqlCommand.Parameters["@SupplierName"].Value = entity.SupplierName;
                sqlCommand.Parameters.Add("@SupplierAddress", SqlDbType.VarChar);
                sqlCommand.Parameters["@SupplierAddress"].Value = entity.SupplierAddress;
                sqlCommand.Parameters.Add("@SupplierPhoneNo", SqlDbType.BigInt);
                sqlCommand.Parameters["@SupplierPhoneNo"].Value = entity.SupplierPhoneNo;
                int res = sqlCommand.ExecuteNonQuery();
                if (res > 0)
                    return true;


            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                DbConnection.CloseConnection(sqlConnection);
            }
            return false;
        }



    }
}
