﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DataAccessLayer
{
    public static class DbConnection
    {

        static SqlConnection sqlConnection = null;
        public static SqlConnection OpenConnection()
        {
            try
            {
                sqlConnection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=GFP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
                sqlConnection.Open();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return sqlConnection;
        }

        public static void CloseConnection(SqlConnection sqlConnection)
        {
            try
            {

                sqlConnection.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}
