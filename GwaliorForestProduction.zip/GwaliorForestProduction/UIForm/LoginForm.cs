﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace UIForm
{
    public partial class LoginForm : Form
    {
        BusinessAccessBAL bal = new BusinessAccessBAL();
       
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }


       
       
            //EntityLayer entity = new EntityLayer();


        private void btnLogin_Click(object sender, EventArgs e)
        {
            //declaring the local variables
            string username = "";
            string password = "";
            username = textUserName.Text;
            password = textPassword.Text;




            //assigning the value to entity with the local stored value
           EntityAccessEAL entity = new EntityAccessEAL();

            entity.UserName = username;
            entity.Password = password;
           
            



            //validating the username
            if (string.IsNullOrEmpty(username) || string.IsNullOrWhiteSpace(username))
            {
                errorProvider1.SetError(textUserName, "Name cannot be blank");
            }
            else
                errorProvider1.SetError(textUserName, string.Empty);


            //validating the password
            if (string.IsNullOrEmpty(password) || string.IsNullOrWhiteSpace(password))
            {
                errorProvider1.SetError(textPassword, "Password cannot be blank");
            }
            else
                errorProvider1.SetError(textPassword, string.Empty);

            //LoginVerification method for verifying the user 

            try
            {

                bool result = bal.AdminLogin(entity,password);
                if (result)
                {
                    MessageBox.Show("Access Granted");
                    this.Hide();
                    Departments departments = new Departments();
                    departments.ShowDialog();
                }
                else
                    MessageBox.Show("Access Denied");
               // this.registrationTableAdapter.Fill(this.trainingExampleDataSet.Registration);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    }
}
