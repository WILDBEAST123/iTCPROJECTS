﻿namespace UIForm
{
    partial class CustomerOrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerOrderForm));
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbParsley = new System.Windows.Forms.Label();
            this.lbThyme = new System.Windows.Forms.Label();
            this.lbBasil = new System.Windows.Forms.Label();
            this.lbMint = new System.Windows.Forms.Label();
            this.cbParskey = new System.Windows.Forms.ComboBox();
            this.cbBasil = new System.Windows.Forms.ComboBox();
            this.cbThyme = new System.Windows.Forms.ComboBox();
            this.cbMint = new System.Windows.Forms.ComboBox();
            this.btnAddParsley = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.lb200 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAddThyme = new System.Windows.Forms.Button();
            this.btnAddBasil = new System.Windows.Forms.Button();
            this.btnAddMint = new System.Windows.Forms.Button();
            this.btnCustomerRegister = new System.Windows.Forms.Button();
            this.btnCustomerAlreadyExists = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(466, 258);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(228, 161);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(466, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(228, 155);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(63, 262);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(237, 161);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.ErrorImage")));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(63, 32);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(237, 155);
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // lbParsley
            // 
            this.lbParsley.AutoSize = true;
            this.lbParsley.Location = new System.Drawing.Point(64, 210);
            this.lbParsley.Name = "lbParsley";
            this.lbParsley.Size = new System.Drawing.Size(41, 13);
            this.lbParsley.TabIndex = 7;
            this.lbParsley.Text = "Parsley";
            this.lbParsley.Click += new System.EventHandler(this.lbParsley_Click);
            // 
            // lbThyme
            // 
            this.lbThyme.AutoSize = true;
            this.lbThyme.Location = new System.Drawing.Point(463, 210);
            this.lbThyme.Name = "lbThyme";
            this.lbThyme.Size = new System.Drawing.Size(39, 13);
            this.lbThyme.TabIndex = 8;
            this.lbThyme.Text = "Thyme";
            // 
            // lbBasil
            // 
            this.lbBasil.AutoSize = true;
            this.lbBasil.Location = new System.Drawing.Point(64, 441);
            this.lbBasil.Name = "lbBasil";
            this.lbBasil.Size = new System.Drawing.Size(29, 13);
            this.lbBasil.TabIndex = 9;
            this.lbBasil.Text = "Basil";
            // 
            // lbMint
            // 
            this.lbMint.AutoSize = true;
            this.lbMint.Location = new System.Drawing.Point(463, 444);
            this.lbMint.Name = "lbMint";
            this.lbMint.Size = new System.Drawing.Size(27, 13);
            this.lbMint.TabIndex = 10;
            this.lbMint.Text = "Mint";
            // 
            // cbParskey
            // 
            this.cbParskey.FormattingEnabled = true;
            this.cbParskey.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbParskey.Location = new System.Drawing.Point(179, 202);
            this.cbParskey.Name = "cbParskey";
            this.cbParskey.Size = new System.Drawing.Size(121, 21);
            this.cbParskey.TabIndex = 11;
            this.cbParskey.Text = "Quantity";
            this.cbParskey.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cbBasil
            // 
            this.cbBasil.FormattingEnabled = true;
            this.cbBasil.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbBasil.Location = new System.Drawing.Point(179, 441);
            this.cbBasil.Name = "cbBasil";
            this.cbBasil.Size = new System.Drawing.Size(121, 21);
            this.cbBasil.TabIndex = 12;
            this.cbBasil.Text = "Quantity";
            // 
            // cbThyme
            // 
            this.cbThyme.FormattingEnabled = true;
            this.cbThyme.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbThyme.Location = new System.Drawing.Point(573, 202);
            this.cbThyme.Name = "cbThyme";
            this.cbThyme.Size = new System.Drawing.Size(121, 21);
            this.cbThyme.TabIndex = 13;
            this.cbThyme.Text = "Quantity";
            // 
            // cbMint
            // 
            this.cbMint.FormattingEnabled = true;
            this.cbMint.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbMint.Location = new System.Drawing.Point(573, 441);
            this.cbMint.Name = "cbMint";
            this.cbMint.Size = new System.Drawing.Size(121, 21);
            this.cbMint.TabIndex = 14;
            this.cbMint.Text = "Quantity";
            // 
            // btnAddParsley
            // 
            this.btnAddParsley.Location = new System.Drawing.Point(225, 238);
            this.btnAddParsley.Name = "btnAddParsley";
            this.btnAddParsley.Size = new System.Drawing.Size(75, 23);
            this.btnAddParsley.TabIndex = 15;
            this.btnAddParsley.Text = "Add Cart";
            this.btnAddParsley.UseVisualStyleBackColor = true;
            this.btnAddParsley.Click += new System.EventHandler(this.btnAddParsley_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(355, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Products";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(13, 3);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 17;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lb200
            // 
            this.lb200.AutoSize = true;
            this.lb200.Location = new System.Drawing.Point(64, 243);
            this.lb200.Name = "lb200";
            this.lb200.Size = new System.Drawing.Size(41, 13);
            this.lb200.TabIndex = 18;
            this.lb200.Text = "Rs 200";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(467, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Rs 300";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(64, 472);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Rs 400";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(467, 478);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Rs 500";
            // 
            // btnAddThyme
            // 
            this.btnAddThyme.Location = new System.Drawing.Point(619, 229);
            this.btnAddThyme.Name = "btnAddThyme";
            this.btnAddThyme.Size = new System.Drawing.Size(75, 23);
            this.btnAddThyme.TabIndex = 22;
            this.btnAddThyme.Text = "Add Cart";
            this.btnAddThyme.UseVisualStyleBackColor = true;
            this.btnAddThyme.Click += new System.EventHandler(this.btnAddThyme_Click);
            // 
            // btnAddBasil
            // 
            this.btnAddBasil.Location = new System.Drawing.Point(225, 468);
            this.btnAddBasil.Name = "btnAddBasil";
            this.btnAddBasil.Size = new System.Drawing.Size(75, 23);
            this.btnAddBasil.TabIndex = 23;
            this.btnAddBasil.Text = "Add Cart";
            this.btnAddBasil.UseVisualStyleBackColor = true;
            this.btnAddBasil.Click += new System.EventHandler(this.btnAddBasil_Click);
            // 
            // btnAddMint
            // 
            this.btnAddMint.Location = new System.Drawing.Point(619, 468);
            this.btnAddMint.Name = "btnAddMint";
            this.btnAddMint.Size = new System.Drawing.Size(75, 23);
            this.btnAddMint.TabIndex = 24;
            this.btnAddMint.Text = "Add Cart";
            this.btnAddMint.UseVisualStyleBackColor = true;
            this.btnAddMint.Click += new System.EventHandler(this.btnAddMint_Click);
            // 
            // btnCustomerRegister
            // 
            this.btnCustomerRegister.Location = new System.Drawing.Point(767, 151);
            this.btnCustomerRegister.Name = "btnCustomerRegister";
            this.btnCustomerRegister.Size = new System.Drawing.Size(95, 51);
            this.btnCustomerRegister.TabIndex = 25;
            this.btnCustomerRegister.Text = "Register";
            this.btnCustomerRegister.UseVisualStyleBackColor = true;
            this.btnCustomerRegister.Click += new System.EventHandler(this.btnCustomerRegister_Click);
            // 
            // btnCustomerAlreadyExists
            // 
            this.btnCustomerAlreadyExists.Location = new System.Drawing.Point(767, 292);
            this.btnCustomerAlreadyExists.Name = "btnCustomerAlreadyExists";
            this.btnCustomerAlreadyExists.Size = new System.Drawing.Size(95, 47);
            this.btnCustomerAlreadyExists.TabIndex = 26;
            this.btnCustomerAlreadyExists.Text = "Already Exists";
            this.btnCustomerAlreadyExists.UseVisualStyleBackColor = true;
            this.btnCustomerAlreadyExists.Click += new System.EventHandler(this.btnCustomerAlreadyExists_Click);
            // 
            // CustomerOrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 492);
            this.Controls.Add(this.btnCustomerAlreadyExists);
            this.Controls.Add(this.btnCustomerRegister);
            this.Controls.Add(this.btnAddMint);
            this.Controls.Add(this.btnAddBasil);
            this.Controls.Add(this.btnAddThyme);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lb200);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAddParsley);
            this.Controls.Add(this.cbMint);
            this.Controls.Add(this.cbThyme);
            this.Controls.Add(this.cbBasil);
            this.Controls.Add(this.cbParskey);
            this.Controls.Add(this.lbMint);
            this.Controls.Add(this.lbBasil);
            this.Controls.Add(this.lbThyme);
            this.Controls.Add(this.lbParsley);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox4);
            this.Name = "CustomerOrderForm";
            this.Text = "Quantity";
            this.Load += new System.EventHandler(this.CustomerOrder_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lbParsley;
        private System.Windows.Forms.Label lbThyme;
        private System.Windows.Forms.Label lbBasil;
        private System.Windows.Forms.Label lbMint;
        private System.Windows.Forms.ComboBox cbParskey;
        private System.Windows.Forms.ComboBox cbBasil;
        private System.Windows.Forms.ComboBox cbThyme;
        private System.Windows.Forms.ComboBox cbMint;
        private System.Windows.Forms.Button btnAddParsley;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lb200;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnAddThyme;
        private System.Windows.Forms.Button btnAddBasil;
        private System.Windows.Forms.Button btnAddMint;
        private System.Windows.Forms.Button btnCustomerRegister;
        private System.Windows.Forms.Button btnCustomerAlreadyExists;
    }
}