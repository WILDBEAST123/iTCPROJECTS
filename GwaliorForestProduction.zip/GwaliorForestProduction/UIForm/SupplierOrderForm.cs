﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace UIForm
{
    public partial class SupplierOrderForm : Form
    {
       public static EntityAccessEAL entityAccessEAL1 = new EntityAccessEAL();
        BusinessAccessBAL bal = new BusinessAccessBAL();
        
        public SupplierOrderForm()
        {
            InitializeComponent();
        }

        private void btnSupplierSubmit_Click(object sender, EventArgs e)
        {
            //string supplierdepartmentname;
            //string supplierparsely;
            //string supplierthyme;
            //string supplierbasil;
            //string suppliermint;

           // supplierdepartmentname = textSupplierDepartment.Text;
            //supplierparsely = textSupplierParsely.Text;
            //supplierthyme = textSupplierThyme.Text;
            //supplierbasil = textSupplierBasil.Text;
            //suppliermint = textSupplierMint.Text;
          //  entityAccessEAL1.SupplierDepartmentName = textSupplierDepartment.Text;
            //entityAccessEAL1.SupplierParselyName = "Parsely";
            //entityAccessEAL1.SupplierThymeName = "Thyme";
            //entityAccessEAL1.SupplierBasilName = "Basil";
            //entityAccessEAL1.SupplierMintName = "Mint";
            //entityAccessEAL1.SupplierParselyQuantity = textSupplierParsely.Text;
            //entityAccessEAL1.SupplierThymeQuantity = textSupplierThyme.Text;
            //entityAccessEAL1.SupplierBasilQuantity = textSupplierBasil.Text;
            //entityAccessEAL1.SupplierMintQuantity = textSupplierMint.Text;



        }

        private void btnSupplierRegister_Click(object sender, EventArgs e)
        {
            entityAccessEAL1.SupplierDepartmentName = textSupplierDepartment.Text;
            this.Hide();
            SupplierDetailsEntryForm supplierDetailsEntryForm = new SupplierDetailsEntryForm();
            supplierDetailsEntryForm.Show();

            this.Close();
        }

        private void btnSupplierBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Departments departments = new Departments();
            departments.Show();
            this.Hide();
        }

        private void btnAddParsely_Click(object sender, EventArgs e)
        {
            entityAccessEAL1.SupplierParselyName = "Parsely";
            entityAccessEAL1.SupplierParselyQuantity = textSupplierParsely.Text;

            entityAccessEAL1.SupplierProductQuantity += entityAccessEAL1.SupplierParselyQuantity + ",";
            entityAccessEAL1.SupplierProductName += entityAccessEAL1.SupplierParselyName + ",";
            MessageBox.Show(entityAccessEAL1.SupplierProductName);

            MessageBox.Show(entityAccessEAL1.SupplierParselyQuantity);
            MessageBox.Show(entityAccessEAL1.SupplierParselyName);


        }

        private void btnAddThyme_Click(object sender, EventArgs e)
        {
            entityAccessEAL1.SupplierThymeName = "Thyme";
            entityAccessEAL1.SupplierThymeQuantity = textSupplierThyme.Text;
            entityAccessEAL1.SupplierProductQuantity += entityAccessEAL1.SupplierThymeQuantity + ",";
            entityAccessEAL1.SupplierProductName += entityAccessEAL1.SupplierThymeName + ",";

        }

        private void btnAddBasil_Click(object sender, EventArgs e)
        {
            entityAccessEAL1.SupplierBasilName = "Basil";
            entityAccessEAL1.SupplierBasilQuantity = textSupplierBasil.Text;

            entityAccessEAL1.SupplierProductQuantity += entityAccessEAL1.SupplierBasilQuantity + ",";
            entityAccessEAL1.SupplierProductName += entityAccessEAL1.SupplierBasilName + ",";

        }

        private void btnAddMint_Click(object sender, EventArgs e)
        {
            entityAccessEAL1.SupplierMintName = "Mint";
            entityAccessEAL1.SupplierMintQuantity = textSupplierMint.Text;

            entityAccessEAL1.SupplierProductQuantity += entityAccessEAL1.SupplierMintQuantity + ",";
            entityAccessEAL1.SupplierProductName += entityAccessEAL1.SupplierMintName + ",";
            MessageBox.Show(entityAccessEAL1.SupplierProductName);
            MessageBox.Show(entityAccessEAL1.SupplierProductQuantity);


        }
    }
}
