﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace UIForm
{
    public partial class CustomerOrderForm : Form
    {
        public CustomerOrderForm()
        {
            InitializeComponent();
        }

        private void CustomerOrder_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Departments departments = new Departments();
            departments.Show();
            this.Close();
            //CustomerDetailsEntryForm customerDetailsEntry = new CustomerDetailsEntryForm();
            //customerDetailsEntry.Show();
        }

        private void lbParsley_Click(object sender, EventArgs e)
        {

        }
       

       

        public static EntityAccessEAL entityAccessEAL = new EntityAccessEAL();


        //Parsley data fetching
        private void btnAddParsley_Click(object sender, EventArgs e)
        {

            int parsleyquantity;
            int parsleytotalcost;

            //string productname = "";
            //foreach (var t in lbSkillSets.CheckedItems)
                


            parsleyquantity = Convert.ToInt32(cbParskey.SelectedItem.ToString());
           // MessageBox.Show(Convert.ToString(parsleyquantity));
            parsleytotalcost = parsleyquantity * 200;
            entityAccessEAL.ParsleyQuantity = parsleyquantity;
            entityAccessEAL.ParsleyTotalCost = parsleytotalcost;
            entityAccessEAL.ParsleyName ="Parsley";
            entityAccessEAL.ProductName += entityAccessEAL.ParsleyName + ",";
            entityAccessEAL.ProductQuantity += entityAccessEAL.ParsleyQuantity + ",";
            entityAccessEAL.ProductTotalAmount += entityAccessEAL.ParsleyTotalCost;
            //MessageBox.Show(entityAccessEAL.ParsleyName);
            MessageBox.Show(Convert.ToString(entityAccessEAL.ParsleyTotalCost));
        }


        private void btnAddThyme_Click(object sender, EventArgs e)
        {
            int thymequantity;
            int thymetotalcost;
            thymequantity = Convert.ToInt32(cbThyme.SelectedItem.ToString());
            thymetotalcost = thymequantity * 300;
            entityAccessEAL.ThymeQuantity = thymequantity;
            entityAccessEAL.ThymeTotalCost = thymetotalcost;
            entityAccessEAL.ThymeName = "Thyme";
            entityAccessEAL.ProductName += entityAccessEAL.ThymeName + ",";
            entityAccessEAL.ProductQuantity += entityAccessEAL.ThymeQuantity + ",";
            entityAccessEAL.ProductTotalAmount += entityAccessEAL.ThymeTotalCost;

            MessageBox.Show(Convert.ToString(entityAccessEAL.ThymeTotalCost));
        }

        private void btnAddBasil_Click(object sender, EventArgs e)
        {
            int basilquantity;
            int basiltotalcost;
            basilquantity = Convert.ToInt32(cbBasil.SelectedItem.ToString());
            basiltotalcost = basilquantity * 400;
            entityAccessEAL.BasilQuantity = basilquantity;
            entityAccessEAL.BasilTotalCost = basiltotalcost;
            entityAccessEAL.BasilName = "Basil";
            entityAccessEAL.ProductName += entityAccessEAL.BasilName + ",";
            entityAccessEAL.ProductQuantity += entityAccessEAL.BasilQuantity + ",";
            entityAccessEAL.ProductTotalAmount += entityAccessEAL.BasilTotalCost;
            MessageBox.Show(Convert.ToString(entityAccessEAL.BasilTotalCost));
        }

        private void btnAddMint_Click(object sender, EventArgs e)
        {
            int mintquantity;
            int minttotalcost;
            mintquantity = Convert.ToInt32(cbMint.SelectedItem.ToString());
            minttotalcost = mintquantity * 500;
            entityAccessEAL.MintQuantity = mintquantity;
            entityAccessEAL.MintTotalCost = minttotalcost;
            entityAccessEAL.MintName = "Mint";
            entityAccessEAL.ProductName += entityAccessEAL.MintName + ",";
            entityAccessEAL.ProductQuantity += entityAccessEAL.MintQuantity + ",";
            entityAccessEAL.ProductTotalAmount += entityAccessEAL.MintTotalCost;

            MessageBox.Show(Convert.ToString(entityAccessEAL.MintTotalCost));
        }

        //public EntityAccessEAL GetOderValue()
        //{
        //    // EntityAccessEAL eAL = new EntityAccessEAL();
        //    Console.WriteLine(entityAccessEAL.ParsleyQuantity);
        //    return entityAccessEAL;
           
        //}

        private void btnCustomerAlreadyExists_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerExistsData customerExistsData = new CustomerExistsData();
            customerExistsData.Show();
            //this.Close();
        }


        private void btnCustomerRegister_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Parsley Quantity" + entityAccessEAL.ParsleyQuantity + "  Parsley Total Price" + entityAccessEAL.ParsleyTotalCost + "\n" + "Thyme Quantity:" + entityAccessEAL.ThymeQuantity + " Thyme Total Price:" + "\n" + entityAccessEAL.ThymeTotalCost + "\n" + "Basil Quantity: " + entityAccessEAL.BasilQuantity + " Basil Total Price: " + entityAccessEAL.BasilTotalCost + "\n" + "Mint Quantity:" + entityAccessEAL.MintQuantity + " Mint Total Price:" + entityAccessEAL.MintTotalCost);

            CustomerDetailsEntryForm customerDetailsEntryForm = new CustomerDetailsEntryForm();
            customerDetailsEntryForm.Show();
            //this.Close();
        }
    }
}
