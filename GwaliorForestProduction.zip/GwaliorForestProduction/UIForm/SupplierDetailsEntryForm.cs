﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace UIForm
{
    public partial class SupplierDetailsEntryForm : Form
    {
        public SupplierDetailsEntryForm()
        {
            InitializeComponent();
        }
        EntityAccessEAL entity = new EntityAccessEAL();
        BusinessAccessBAL bal = new BusinessAccessBAL();
        private void textCustomerName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSupplierRegister_Click(object sender, EventArgs e)
        {
            
            entity.SupplierName = textSupplierName.Text;
            entity.SupplierAddress = textSupplierAddress.Text;
            entity.SupplierPhoneNo = textSupplierPhone.Text;
            EntityAccessEAL entityAccessEAL = SupplierOrderForm.entityAccessEAL1;
            try
            {

                bool result = bal.InsertSupplierData(entity);
                int supplierid = bal.FetchSupplierID(entity);
                MessageBox.Show(Convert.ToString(supplierid));
               bal.InsertSupplierOrderData(CustomerOrderForm.entityAccessEAL, supplierid);

                if (result)
                {

                    MessageBox.Show("Supplier Data Updated");
                    MessageBox.Show(entityAccessEAL.SupplierProductName);
                    MessageBox.Show(entityAccessEAL.SupplierProductQuantity);
                    MessageBox.Show("Supplier Name: " + entity.SupplierName + "\n" + "Supplier Address: " + entity.SupplierAddress + "\n" + "Supplier Phone Number:\n " + entity.SupplierPhoneNo +"Department Name: "+ entityAccessEAL.SupplierDepartmentName + "\n" + "Product Name" + entityAccessEAL.SupplierParselyName +"Product Quantity"+entityAccessEAL.SupplierParselyQuantity+ "\n" + "Product Name" +entityAccessEAL.SupplierThymeName+"Product Quantity"+entityAccessEAL.SupplierThymeQuantity+ "\n" + "Product Name" + entityAccessEAL.SupplierBasilName + "Product Quantity" + entityAccessEAL.SupplierBasilQuantity + "\n" + "Product Name" + entityAccessEAL.SupplierMintName + "Product Quantity" + entityAccessEAL.SupplierMintQuantity);

                    //this.Hide();
                    //Departments departments = new Departments();
                    //departments.ShowDialog();
                }
                else
                    MessageBox.Show("Data Entry Falied");
                //this.registrationTableAdapter.Fill(this.trainingExampleDataSet.Registration);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            SupplierOrderForm supplierOrderForm = new SupplierOrderForm();
            supplierOrderForm.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }
    }
}
