﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UIForm
{
    public partial class Departments : Form
    {
        public Departments()
        {
            InitializeComponent();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerOrderForm customerOrderForm = new CustomerOrderForm();
            customerOrderForm.Show();
            this.Close();
            //CustomerDetailsEntryForm customerDetailsEntry = new CustomerDetailsEntryForm();
            //customerDetailsEntry.ShowDialog();





        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            this.Hide();
            SupplierOrderForm supplierOrderForm = new SupplierOrderForm();
            supplierOrderForm.Show();
            this.Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }

        private void btnLab_Click(object sender, EventArgs e)
        {

        }
    }
}
