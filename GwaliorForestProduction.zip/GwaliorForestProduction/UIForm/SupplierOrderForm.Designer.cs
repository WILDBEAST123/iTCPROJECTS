﻿namespace UIForm
{
    partial class SupplierOrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textSupplierParsely = new System.Windows.Forms.TextBox();
            this.textSupplierThyme = new System.Windows.Forms.TextBox();
            this.textSupplierBasil = new System.Windows.Forms.TextBox();
            this.textSupplierMint = new System.Windows.Forms.TextBox();
            this.btnSupplierSubmit = new System.Windows.Forms.Button();
            this.textSupplierDepartment = new System.Windows.Forms.TextBox();
            this.btnSupplierRegister = new System.Windows.Forms.Button();
            this.btnSupplierAlready = new System.Windows.Forms.Button();
            this.btnSupplierBack = new System.Windows.Forms.Button();
            this.btnAddParsely = new System.Windows.Forms.Button();
            this.btnAddThyme = new System.Windows.Forms.Button();
            this.btnAddBasil = new System.Windows.Forms.Button();
            this.btnAddMint = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(134, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Department Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter The Product Quantity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(300, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Supplier Entry Details";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(183, 184);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Parsely";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(183, 220);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Thyme";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(183, 263);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Basil";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(183, 299);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Mint";
            // 
            // textSupplierParsely
            // 
            this.textSupplierParsely.Location = new System.Drawing.Point(307, 181);
            this.textSupplierParsely.Name = "textSupplierParsely";
            this.textSupplierParsely.Size = new System.Drawing.Size(100, 20);
            this.textSupplierParsely.TabIndex = 8;
            // 
            // textSupplierThyme
            // 
            this.textSupplierThyme.Location = new System.Drawing.Point(307, 220);
            this.textSupplierThyme.Name = "textSupplierThyme";
            this.textSupplierThyme.Size = new System.Drawing.Size(100, 20);
            this.textSupplierThyme.TabIndex = 9;
            // 
            // textSupplierBasil
            // 
            this.textSupplierBasil.Location = new System.Drawing.Point(307, 260);
            this.textSupplierBasil.Name = "textSupplierBasil";
            this.textSupplierBasil.Size = new System.Drawing.Size(100, 20);
            this.textSupplierBasil.TabIndex = 10;
            // 
            // textSupplierMint
            // 
            this.textSupplierMint.Location = new System.Drawing.Point(307, 296);
            this.textSupplierMint.Name = "textSupplierMint";
            this.textSupplierMint.Size = new System.Drawing.Size(100, 20);
            this.textSupplierMint.TabIndex = 11;
            // 
            // btnSupplierSubmit
            // 
            this.btnSupplierSubmit.Location = new System.Drawing.Point(307, 369);
            this.btnSupplierSubmit.Name = "btnSupplierSubmit";
            this.btnSupplierSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSupplierSubmit.TabIndex = 12;
            this.btnSupplierSubmit.Text = "Submit";
            this.btnSupplierSubmit.UseVisualStyleBackColor = true;
            this.btnSupplierSubmit.Click += new System.EventHandler(this.btnSupplierSubmit_Click);
            // 
            // textSupplierDepartment
            // 
            this.textSupplierDepartment.Location = new System.Drawing.Point(307, 73);
            this.textSupplierDepartment.Name = "textSupplierDepartment";
            this.textSupplierDepartment.Size = new System.Drawing.Size(100, 20);
            this.textSupplierDepartment.TabIndex = 13;
            // 
            // btnSupplierRegister
            // 
            this.btnSupplierRegister.Location = new System.Drawing.Point(583, 178);
            this.btnSupplierRegister.Name = "btnSupplierRegister";
            this.btnSupplierRegister.Size = new System.Drawing.Size(86, 23);
            this.btnSupplierRegister.TabIndex = 14;
            this.btnSupplierRegister.Text = "Register";
            this.btnSupplierRegister.UseVisualStyleBackColor = true;
            this.btnSupplierRegister.Click += new System.EventHandler(this.btnSupplierRegister_Click);
            // 
            // btnSupplierAlready
            // 
            this.btnSupplierAlready.Location = new System.Drawing.Point(583, 243);
            this.btnSupplierAlready.Name = "btnSupplierAlready";
            this.btnSupplierAlready.Size = new System.Drawing.Size(86, 23);
            this.btnSupplierAlready.TabIndex = 15;
            this.btnSupplierAlready.Text = "AlreadyExists";
            this.btnSupplierAlready.UseVisualStyleBackColor = true;
            // 
            // btnSupplierBack
            // 
            this.btnSupplierBack.Location = new System.Drawing.Point(21, 12);
            this.btnSupplierBack.Name = "btnSupplierBack";
            this.btnSupplierBack.Size = new System.Drawing.Size(75, 23);
            this.btnSupplierBack.TabIndex = 16;
            this.btnSupplierBack.Text = "Back";
            this.btnSupplierBack.UseVisualStyleBackColor = true;
            this.btnSupplierBack.Click += new System.EventHandler(this.btnSupplierBack_Click);
            // 
            // btnAddParsely
            // 
            this.btnAddParsely.Location = new System.Drawing.Point(439, 184);
            this.btnAddParsely.Name = "btnAddParsely";
            this.btnAddParsely.Size = new System.Drawing.Size(75, 23);
            this.btnAddParsely.TabIndex = 17;
            this.btnAddParsely.Text = "Add";
            this.btnAddParsely.UseVisualStyleBackColor = true;
            this.btnAddParsely.Click += new System.EventHandler(this.btnAddParsely_Click);
            // 
            // btnAddThyme
            // 
            this.btnAddThyme.Location = new System.Drawing.Point(439, 218);
            this.btnAddThyme.Name = "btnAddThyme";
            this.btnAddThyme.Size = new System.Drawing.Size(75, 23);
            this.btnAddThyme.TabIndex = 18;
            this.btnAddThyme.Text = "Add";
            this.btnAddThyme.UseVisualStyleBackColor = true;
            this.btnAddThyme.Click += new System.EventHandler(this.btnAddThyme_Click);
            // 
            // btnAddBasil
            // 
            this.btnAddBasil.Location = new System.Drawing.Point(439, 253);
            this.btnAddBasil.Name = "btnAddBasil";
            this.btnAddBasil.Size = new System.Drawing.Size(75, 23);
            this.btnAddBasil.TabIndex = 19;
            this.btnAddBasil.Text = "Add";
            this.btnAddBasil.UseVisualStyleBackColor = true;
            this.btnAddBasil.Click += new System.EventHandler(this.btnAddBasil_Click);
            // 
            // btnAddMint
            // 
            this.btnAddMint.Location = new System.Drawing.Point(439, 296);
            this.btnAddMint.Name = "btnAddMint";
            this.btnAddMint.Size = new System.Drawing.Size(75, 23);
            this.btnAddMint.TabIndex = 20;
            this.btnAddMint.Text = "Add";
            this.btnAddMint.UseVisualStyleBackColor = true;
            this.btnAddMint.Click += new System.EventHandler(this.btnAddMint_Click);
            // 
            // SupplierOrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAddMint);
            this.Controls.Add(this.btnAddBasil);
            this.Controls.Add(this.btnAddThyme);
            this.Controls.Add(this.btnAddParsely);
            this.Controls.Add(this.btnSupplierBack);
            this.Controls.Add(this.btnSupplierAlready);
            this.Controls.Add(this.btnSupplierRegister);
            this.Controls.Add(this.textSupplierDepartment);
            this.Controls.Add(this.btnSupplierSubmit);
            this.Controls.Add(this.textSupplierMint);
            this.Controls.Add(this.textSupplierBasil);
            this.Controls.Add(this.textSupplierThyme);
            this.Controls.Add(this.textSupplierParsely);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SupplierOrderForm";
            this.Text = "SupplierOrderForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textSupplierParsely;
        private System.Windows.Forms.TextBox textSupplierThyme;
        private System.Windows.Forms.TextBox textSupplierBasil;
        private System.Windows.Forms.TextBox textSupplierMint;
        private System.Windows.Forms.Button btnSupplierSubmit;
        private System.Windows.Forms.TextBox textSupplierDepartment;
        private System.Windows.Forms.Button btnSupplierRegister;
        private System.Windows.Forms.Button btnSupplierAlready;
        private System.Windows.Forms.Button btnSupplierBack;
        private System.Windows.Forms.Button btnAddParsely;
        private System.Windows.Forms.Button btnAddThyme;
        private System.Windows.Forms.Button btnAddBasil;
        private System.Windows.Forms.Button btnAddMint;
    }
}