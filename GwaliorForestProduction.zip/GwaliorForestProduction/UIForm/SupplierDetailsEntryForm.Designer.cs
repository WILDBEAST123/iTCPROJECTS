﻿namespace UIForm
{
    partial class SupplierDetailsEntryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSupplierRegister = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.textSupplierPhone = new System.Windows.Forms.TextBox();
            this.textSupplierAddress = new System.Windows.Forms.TextBox();
            this.textSupplierName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSupplierRegister
            // 
            this.btnSupplierRegister.Location = new System.Drawing.Point(416, 353);
            this.btnSupplierRegister.Name = "btnSupplierRegister";
            this.btnSupplierRegister.Size = new System.Drawing.Size(75, 23);
            this.btnSupplierRegister.TabIndex = 18;
            this.btnSupplierRegister.Text = "Register";
            this.btnSupplierRegister.UseVisualStyleBackColor = true;
            this.btnSupplierRegister.Click += new System.EventHandler(this.btnSupplierRegister_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 17;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // textSupplierPhone
            // 
            this.textSupplierPhone.Location = new System.Drawing.Point(446, 247);
            this.textSupplierPhone.Name = "textSupplierPhone";
            this.textSupplierPhone.Size = new System.Drawing.Size(100, 20);
            this.textSupplierPhone.TabIndex = 16;
            // 
            // textSupplierAddress
            // 
            this.textSupplierAddress.Location = new System.Drawing.Point(446, 192);
            this.textSupplierAddress.Name = "textSupplierAddress";
            this.textSupplierAddress.Size = new System.Drawing.Size(100, 20);
            this.textSupplierAddress.TabIndex = 15;
            // 
            // textSupplierName
            // 
            this.textSupplierName.Location = new System.Drawing.Point(446, 133);
            this.textSupplierName.Name = "textSupplierName";
            this.textSupplierName.Size = new System.Drawing.Size(100, 20);
            this.textSupplierName.TabIndex = 14;
            this.textSupplierName.TextChanged += new System.EventHandler(this.textCustomerName_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(413, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "SUPPLIER ENTRY";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(297, 247);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Enter Phone Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(297, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Enter Address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(297, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Enter Supplier Name";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(678, 353);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 19;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // SupplierDetailsEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnSupplierRegister);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.textSupplierPhone);
            this.Controls.Add(this.textSupplierAddress);
            this.Controls.Add(this.textSupplierName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SupplierDetailsEntry";
            this.Text = "SupplierDetailsEntry";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSupplierRegister;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox textSupplierPhone;
        private System.Windows.Forms.TextBox textSupplierAddress;
        private System.Windows.Forms.TextBox textSupplierName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLogout;
    }
}