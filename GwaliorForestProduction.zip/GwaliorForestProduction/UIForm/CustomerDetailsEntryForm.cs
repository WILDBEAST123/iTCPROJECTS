﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntityLayer;
using BusinessAccessLayer;

namespace UIForm
{
    public partial class CustomerDetailsEntryForm : Form
    {
        
        public CustomerDetailsEntryForm()
        {
            InitializeComponent();
        }
        EntityAccessEAL entity = new EntityAccessEAL();
        BusinessAccessBAL bal = new BusinessAccessBAL();
        //EntityAccessEAL entityAccessEAL = new EntityAccessEAL();

        private void btnRegister_Click(object sender, EventArgs e)
        {
            //Data insert for new customer when register button is clicked & customer order is updated with id & quantity.
            entity.CustName = textCustomerName.Text;
            entity.CustAddress = textCustomerAddress.Text;
            entity.CustPhoneNo = textCustomerPhone.Text;


            
               
          
            try
            {
                //CustomerOrderForm customerOrderForm = new CustomerOrderForm();
                //EntityAccessEAL eAL = new EntityAccessEAL();
                EntityAccessEAL entityAccessEAL=CustomerOrderForm.entityAccessEAL;
               //MessageBox.Show(Convert.ToString(entityAccessEAL.ThymeQuantity));
                bool result = bal.InsertCustomerData(entity);
               
                //fetching the custid of the recent registered customer
                int customerid = bal.FetchCustomerID(entity);
                MessageBox.Show(Convert.ToString(customerid));
                bal.InsertProdouctData(CustomerOrderForm.entityAccessEAL,customerid);

                if (result)
                {

                    MessageBox.Show(entityAccessEAL.ProductName);
                    MessageBox.Show(entityAccessEAL.ProductQuantity);
                    MessageBox.Show(Convert.ToString(entityAccessEAL.ProductTotalAmount));
                    MessageBox.Show("Customer Data Updated");
                    MessageBox.Show("Customer Name: "+entity.CustName + "\n"+ "Customer Address: " +  entity.CustAddress + "\n"+"Customer Phone Number: " + entity.CustPhoneNo+ "\n" + "Parsley Quantity" + entityAccessEAL.ParsleyQuantity+"  Parsley Total Price"+ entityAccessEAL.ParsleyTotalCost+ "\n" + "Thyme Quantity:" + entityAccessEAL.ThymeQuantity + " Thyme Total Price:" +"\n"+ entityAccessEAL.ThymeTotalCost + "\n" + "Basil Quantity: " + entityAccessEAL.BasilQuantity + " Basil Total Price: " + entityAccessEAL.BasilTotalCost + "\n" + "Mint Quantity:" + entityAccessEAL.MintQuantity + " Mint Total Price:" + entityAccessEAL.MintTotalCost);
                    //this.Hide();              
                }
                else
                    MessageBox.Show("Data Entry Falied");
                // this.registrationTableAdapter.Fill(this.trainingExampleDataSet.Registration);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



           
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerOrderForm customerOrderForm = new CustomerOrderForm();
            customerOrderForm.Show();
            this.Close();
        }


    }
}
