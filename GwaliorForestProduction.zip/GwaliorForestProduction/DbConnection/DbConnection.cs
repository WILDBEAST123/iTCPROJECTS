﻿using System;

namespace DbConnection
{
    public class Class1
    {
    }
}
