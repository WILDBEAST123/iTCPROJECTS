﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using EntityLayer;


namespace BusinessAccessLayer
{
    public class BusinessAccessBAL
    {
        DataAccessDAL dal = new DataAccessDAL();
       public bool AdminLogin(EntityAccessEAL entity,string password)
        {
            return dal.AdminLogin(entity,password);
        }
        public bool InsertCustomerData(EntityAccessEAL entity)
        {
            return dal.InsertCustomerData(entity);
        }

        public bool InsertSupplierData(EntityAccessEAL entity)
        {
            return dal.InsertSupplierData(entity);
            
        }
        public int FetchCustomerID(EntityAccessEAL entity)
        {
            return dal.FetchCustomerID(entity);
        }
        public int FetchSupplierID(EntityAccessEAL entity)
        {
            return dal.FetchSupplierID(entity);
        }
        public void InsertProdouctData( EntityAccessEAL entityAccessEAL,int customerid)
        {
            dal.InsertProdouctData(entityAccessEAL, customerid);
        }
        public void InsertSupplierOrderData(EntityAccessEAL entityAccessEAL1, int supplierid)
        {
            dal.InsertSupplierOrderData(entityAccessEAL1, supplierid);
        }

    }
}
