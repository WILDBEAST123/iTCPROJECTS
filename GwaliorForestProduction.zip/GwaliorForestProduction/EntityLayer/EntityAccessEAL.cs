﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
    public class EntityAccessEAL
    {
        public string UserName { get; set; }

        public string Password{ get; set; }
        public string CustName { get; set; }
        public string CustAddress{ get; set; }
        public string CustPhoneNo { get; set; }
        public string SupplierName { get; set; }
        public string SupplierAddress { get; set; }
        public string SupplierPhoneNo { get; set; }



        public int ParsleyQuantity{ get; set; }
        public int ParsleyTotalCost { get; set; }
        public string ParsleyName { get; set; }

        public int ThymeQuantity { get; set; }
        public int ThymeTotalCost { get; set; }
        public string ThymeName { get; set; }


        public int MintQuantity { get; set; }
        public int MintTotalCost { get; set; }
        public string MintName { get; set; }


        public int BasilQuantity { get; set; }
        public int BasilTotalCost { get; set; }
        public string BasilName { get; set; }

        public string ProductName { get; set; }
        public string ProductQuantity { get; set; }
        public int ProductTotalAmount { get; set; }

        public string SupplierDepartmentName { get; set; }
        public string SupplierParselyName{ get; set; }
        public string SupplierThymeName { get; set; }
        public string SupplierBasilName { get; set; }
        public string SupplierMintName { get; set; }
        public string SupplierParselyQuantity { get; set; }
        public string SupplierThymeQuantity { get; set; }
        public string SupplierBasilQuantity { get; set; }
        public string SupplierMintQuantity { get; set; }

        public string SupplierProductName { get; set; }
        public string SupplierProductQuantity { get; set; }

    }
}
